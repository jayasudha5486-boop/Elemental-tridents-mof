ELEMENTAL TRIDENTS - FABRIC MOD
Minecraft Java Edition 1.21.1

I selected Fabric because it is lightweight and beginner-friendly.

10 tridents and right-click powers:
Fire: Fire Resistance
Ice: Slow Falling
Thunder: Speed II
Shadow: Invisibility
Nature: Regeneration
Ocean: Water Breathing
Sun: Night Vision
Cosmic: Jump Boost II + Slow Falling
Earth: Resistance
Ultimate: Speed II + Regeneration + Resistance + Fire Resistance

Each trident has an 8-second cooldown. Items appear in the Creative Combat tab.

Requirements: Minecraft Java 1.21.1, Java 21, Fabric Loader 0.16.5+, and Fabric API for 1.21.1.

BUILD:
1. Install Java 21 and Fabric Loader for Minecraft 1.21.1.
2. Install IntelliJ IDEA Community Edition (or another Gradle IDE).
3. Open this project folder.
4. Run the Gradle task 'build'.
5. The JAR will appear in build/libs/.
6. Put that JAR and Fabric API in .minecraft/mods.

This download is a source project, not a precompiled JAR. It has not been compiled or tested in-game here.
