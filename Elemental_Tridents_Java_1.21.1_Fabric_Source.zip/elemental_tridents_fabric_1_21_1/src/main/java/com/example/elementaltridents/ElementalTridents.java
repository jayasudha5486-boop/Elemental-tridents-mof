package com.example.elementaltridents;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.*;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.*;
import net.minecraft.world.World;
import net.minecraft.entity.player.PlayerEntity;

public class ElementalTridents implements ModInitializer {
    public static final String MOD_ID = "elementaltridents";
    private static Identifier id(String path) { return Identifier.of(MOD_ID, path); }

    @Override public void onInitialize() {
        add("fire_trident", Power.FIRE);
        add("ice_trident", Power.ICE);
        add("thunder_trident", Power.THUNDER);
        add("shadow_trident", Power.SHADOW);
        add("nature_trident", Power.NATURE);
        add("ocean_trident", Power.OCEAN);
        add("sun_trident", Power.SUN);
        add("cosmic_trident", Power.COSMIC);
        add("earth_trident", Power.EARTH);
        add("ultimate_trident", Power.ULTIMATE);
    }

    private void add(String name, Power power) {
        RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, id(name));
        Item item = Registry.register(Registries.ITEM, key,
            new ElementalTrident(power, new Item.Settings().registryKey(key).maxCount(1)));
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> entries.add(item));
    }

    enum Power { FIRE, ICE, THUNDER, SHADOW, NATURE, OCEAN, SUN, COSMIC, EARTH, ULTIMATE }

    static class ElementalTrident extends Item {
        private final Power power;
        ElementalTrident(Power power, Settings settings) { super(settings); this.power = power; }

        @Override public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
            ItemStack stack = player.getStackInHand(hand);
            if (!world.isClient) {
                switch (power) {
                    case FIRE -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 400, 0));
                    case ICE -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 300, 0));
                    case THUNDER -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 1));
                    case SHADOW -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.INVISIBILITY, 200, 0));
                    case NATURE -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 0));
                    case OCEAN -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.WATER_BREATHING, 600, 0));
                    case SUN -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600, 0));
                    case COSMIC -> {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 300, 1));
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 300, 0));
                    }
                    case EARTH -> player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 240, 0));
                    case ULTIMATE -> {
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 1));
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 0));
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 200, 0));
                        player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 300, 0));
                    }
                }
                player.getItemCooldownManager().set(this, 160);
            }
            return TypedActionResult.success(stack, world.isClient);
        }
    }
}
